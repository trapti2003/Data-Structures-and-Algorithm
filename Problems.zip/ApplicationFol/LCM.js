/*
//LCM promise
var n1=15, n2=20;
function getLCM(n1, n2) {
 return new Promise((res)=>{
  let max = (n1>n2) ? n1 : n2;
  let lcm = max;
  while(lcm%n1!=0 || lcm%n2!=0) {
   lcm += max;
  }
  res(lcm);
 });
}
getLCM(n1,n2).then((result)=>{
 console.log(`${result} is the LCM of ${n1} & ${n2}`);
});
*/

/*
//Async-await 
var n1=15,n2=20;
function getLCM(n1,n2){
    return new Promise((res) => {
        let max = (n1>n2) ? n1 : n2;
        let lcm = max;
        while(lcm % n1 != 0 || lcm % n2 != 0){
            lcm += max;
        }
        res(lcm);
    });
}

async function Demo(){
console.log(`${await getLCM(n1,n2)} is the LCM of ${n1} & ${n2}`);
}
Demo();
*/


var n1=15,n2=20;
let max = (n1>n2) ? n1:n2;
let lcm = max;
while(lcm % n1 !=0 || lcm % n2 !=0){
    lcm += max;
}
console.log(`${lcm} is the LCM of ${n1} & ${n2}`);



/*

function getLCM(n1,n2){
    return new Promise((res)=>{
        let max = (n1>n2) ? n1:n2;
        let lcm = max;
        while(lcm % n1 != 0 || lcm % n2 != 0){
            lcm += max;
        }
        res(lcm);
    });
}

getLCM(n1,n2).then((result) =>{
    console.log(`${result} is LCM of ${n1} & ${n2}`);
});

*/


var n1=57,n2=98;
let max1 = (n1>n2) ? n1:n2;
let lcm1 = max1;
while(lcm1%n1 != 0 && lcm1%n2 != 0){
    lcm1 += max1;
}
console.log(`${lcm1} of the LCM of ${n1} & ${n2}`);

