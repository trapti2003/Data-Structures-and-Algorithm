/* 
//Default function 
function countVowels(str){
    let count = 0;
    for(const char of str){
        if(char == "a" || char == "e" || char == "i" || char == "o" || char =="u"){
            count ++;
        }
    }
 return count;
}

let str = "Hello";
var digit = countVowels(str);
console.log(digit + " vowels in a string "  + "[" + str + "]");
*/


var countVowels = (str) =>{
    let count = 0;
    for(const char of str){
        if(char == "a" || char == "e" || char == "i" || char == "o" || char == "u"){
            count++;
        }
    }
    return count;
}
let str = "Hiii";
var digit = countVowels(str);
console.log(digit + " vowels in a string " + "[" + str + "]");