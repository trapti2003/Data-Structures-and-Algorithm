//Factorial
function factorial(num){
    var fact = 1;
    for(let i=2; i<=num; i++){
   {
      fact = fact*i;  
   }
   console.log(`${fact}`);
 }
}
 var num = 5;
 factorial(num);