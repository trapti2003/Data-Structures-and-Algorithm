import http from 'http';
http.createServer((req,res) => {
    if(req.url == "/" || req.url == "/home")
     res.write("<h1> Home url inviked </h1>");

   else if(req.url == "/about")
     res.write("<h1> About url invoked </h1>");

   else if(req.url == "/contact")
    res.write("<h1> Contact url invoked </h1>");

   else if(req.url == "/
   
}).listen(8081);