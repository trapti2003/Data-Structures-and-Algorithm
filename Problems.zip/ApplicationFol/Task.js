// 

// Perfect No.
// var num = 28;
// function PerfectNo(){
//     return new Promise((resolve,reject)=>{
// var sum=0;
// for(let i=1; i<num; i++){
//     if(num%i == 0){
//         sum = sum+ i;
//     }
// }
// }
// )};

// PerfectNo();


var num = 6;
function PerfectNo(){
    return new Promise((resolve,reject)=>{
        var sum = 0;
        for(let i=1; i<num; i++){
            if(num%i == 0){
                sum = sum + i;
            }
        }
        if(sum == num){
            resolve(`${num} is a Perfect No.`);
        }
        else{
            resolve(`${num} is not a Perfect No.`);
        }
    });
}

PerfectNo().then((result)=>{
    console.log(result);
}).catch((error)=>{
    console.log(error);
});