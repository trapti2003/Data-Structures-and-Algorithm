let num = 121;
function Pallindrom(num){
    return new Promise((resolve) =>{ 
    let reverse = 0,n;
    for(let i=num; i>0; i=parseInt(i/10)){
        reverse = reverse * 10 + parseInt(i%10);
        // n = num%10;
    }    
    if(reverse == num){
        console.log(`${num} is Pallindrom`);
    }
    else{
        console.log(`${num} is not Pallindrom`);
    }
  });
}

async function Demo(){
    let result = await Pallindrom(num);
    console.log(`${result}`);
}

Demo();




var num1 = 131;
var reverse = 0 , n;
for(let i=num1; i>0; i=parseInt(i/10)){
    reverse = reverse * 10 + parseInt(i%10);
}
if(reverse == num1){
    console.log(`${num1} is Pallindrom`);
}
else{
    console.log(`${num1} is not Pallindrom`);
}