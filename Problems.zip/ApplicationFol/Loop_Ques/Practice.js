//Find the element in array 
var arr = [10,22,23,2,1,5,7];
var n = 13;
var flag = true;
var i;
for(i in arr){
   if(n == arr[i]){
      console.log(`${n} is found at index ${i}`);
      flag = false;
   }
}
if(flag == true){ 
console.log(`${n} is not found`);
}


