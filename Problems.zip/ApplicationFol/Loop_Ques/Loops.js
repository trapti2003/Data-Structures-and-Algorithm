/*
//Factorial
function factorial(num){
   var fact = 1;
   for(let i=2; i<=num; i++)
  {
     fact = fact*i;  
  }
  console.log(`${fact}`);
}

var num = 5;
factorial(num);
*/


/*
function factorial(num){
return new Promise((resolve) => {
  var fact = 1;
  for(let i=2; i<=num; i++){
     fact *= i; 
}
console.log(`${fact}`);
});
}
async function Demo(){
  await factorial(num);
}
var num = 8;
Demo();
*/

/*
function factorial(num){
  return new Promise((resolve) => {
  
});
} 
*/

/*
const n = [24,32,12,33,2];
let text = " ";
n.forEach(myFunction);
function myFunction(32,1,n){
  text += 22 + '<br>';
}
console.log(text);
*/

/*
//map 
const num2 = [];
const num = [3,4,5,2,1];
const num1 = num.map((value,index) => {
return value * 2;
});
console.log(num1);
*/

/*
const num = [4,3,13,19,33];
const over18 = num.filter((value,index) => {
  return value>18;
});
console.log(over18);
*/

/*
const num = [1,3,4,5];
let sum = num.reduce((total,value,index) => {
   return total+value;
});
console.log(sum);
*/


/*
const fruits = ["Banana", "Orange","Apple","Mango"];
const f = fruits.entries();
for(let x of f){
   document.getElementById("demo").innerHTML+=x;
}
*/


/*
var arr = [10,20,30];
var sum=0;
for(let x of arr)
     sum+=x;
console.log(`Sum of all array elements  = ${sum}`);
*/

/*
var arr = [2,3,2,1];
for(let i in arr)
  console.log(i + "<--->" + arr[i]);
*/

/*
var arr = [10,2,34,32,11,3];
var n = 114;
var flag = true;
for(let i in  arr){
if(n == arr[i]){
   console.log(`${n} is found at index ${i}`);
   flag = false;
}
}
if(flag == true){
console.log(`${n} is not found`);
}
*/


var arr = [10,20,3,2,111];
var n = 2;
var flag = true;
for(let i in arr){
if(n == arr[i]){
console.log(`${n} is found at index ${i}`);
flag = false;
}
}
if(flag == true){
  console.log(`${n} is not found`);
}



/*
var arr1 = [10,29,32,11];
var n = 10;
function Found(arr1,n){
var flag = true;
for(let i in arr){
if(n == arr[i]){
   console.log(`${n} is found at index ${i}`);
flag = false;
}
}
if(flag == true){
 console.log(`${n} is not found`);
}
}
Found(arr1,n);
*/

/*
var arr = [10,20,32,11];
var l = arr.length;
for(let i=0, j=l-1; i<parseInt(l/2);  i++,j--){
  let temp = arr[i];
  arr[i] = arr[j];
 arr[j] = temp;
}
console.log(`Reverse array : ${arr}`);
*/


/*
var arr = [10,2,21,7,1];
var l = arr.length;
for(let i=0; i<l-1; i++){
  for(let j=0; j<l-1; j++){
     if(arr[j]>arr[j+1]){
     let temp = arr[j];
    arr[j] = arr[j+1];
    arr[j+1] = temp;
    }
  }
}
console.log(`Sorted array : ${arr}`);
*/


var arr = [12,34,2,33,10];
var min = arr[0];
for(let i=1; i<arr.length; i++){
if(arr[i]<min){
  min = arr[i];
}
}
console.log(`Minimum element in array : ${min}`);



var a=10, b=30;
console.log(`Before swapping a = ${a}, b = ${b}`);
let temp = a;
a=b;
b=temp;
console.log(`After swapping a = ${a}, b = ${b}`); 


var arr = [12,32,11,40,3];
var max = arr[0];
for(let i=1; i<arr[i]; i++){
   if(arr[i]>max){
       max = arr[i];  
  }
}
console.log(`Maximum element in array : ${max}`);



/*
var num = 123;
var reverse = 0;
for(let i=num;  i>0;  i=parseInt(i/10)){
   reverse = reverse * 10  + parseInt(i%10);
}
console.log(`Reverse digit : ${reverse}`);
*/


//Pallidrom no.
var num = 121;
var reverse = 0;
for(let i=num; i>0; i=parseInt(i/10)){
   reverse = reverse * 10 + parseInt(i%10);
}
if(reverse == num){
  console.log(`${num} is Pallidrom no.`);
}
else{
 console.log(`${num} is not Pallidrom no.`);
}




var n = 5;
var a=-1,b=1;
for(let i=0; i<=n; i++){
  let temp = a+b;
  a = b;
  b = temp;
console.log(`Fibonacii Series ${temp}`);
}

console.log(`<------------>`);

var n = 12;
var flag = true;
for(let i=2; i<n/2; i++){
   if(n%i == 0){
     flag = false;
  }
}
if(flag) {
console.log(`${n} is Prime no.`);
}
else{
console.log(`${n} is not Prime no.`);
}


var n = 2;
