/*console.log(`Before`);
function demo(cb){
    console.log(`Demo function invoked`);
    cb();
}
demo (()=> {
    console.log("Demo function callback executed");
});
console.log(`After`);
*/

/*
console.log(`Before`);
function demo(cb){
    console.log(`Demo function executed`);
    setTimeout(cb,2000);
}
demo(()=>{
    console.log(`Demo cb function executed`);
});
console.log(`After`);
*/

function add(a,b,cb){
    var c = a+b;
    cb(c);
}
var a=10,b=20;
add(a,b,(result)=>{
    console.log(`Addition = ${result}`);
});


