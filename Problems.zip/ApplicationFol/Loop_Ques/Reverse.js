/*
var arr = [10,20,30,40,50];
var l = arr.length;
for(let i=0, j=l-1; i<parseInt(l/2); i++,j--)
{
    let temp = arr[i];
    arr[i] = arr[j];
    arr[j] = temp; 
}
console.log(`Reverse array : ${arr}`);
*/

var arr = [20,13,25,4,12];
var l = arr.length;
for(let i=0, j=l-1; i<parseInt(l/2); i++,j--){
    let temp = arr[i];
    arr[i] = arr[j];
    arr[j] = temp;
}
console.log(`Reverse array : ${arr}`);