var arr = [1,34,20,140,23];
var min = arr[0];
for(let i=1; i<arr.length; i++){
    if(arr[i]<min)
        min = arr[i];
}
console.log(`Minimum element in array : ${min}`);




/*
var arr1 = [12,45,89,5,23];
var min = arr1[0];
for(let i=1; i<arr1.length; i++){
    if(arr1[i]<min)
        min = arr1[i];
}
console.log(`Minimum element in array is ${min} at index ${i}`);
*/