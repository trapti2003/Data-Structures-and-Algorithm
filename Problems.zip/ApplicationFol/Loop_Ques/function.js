console.log(`Before function execution`);
function demo(){
 console.log(`Demo Function is invoked`);
}
demo();
console.log(`After function execution`);

console.log(`<-------------->`);
function add(a,b){
  return a+b;
}
function checkEvenOdd(n){
  if(n%2 == 0){
     console.log(`${n} is Even`);
  }
  else {
   console.log(`${n} is Odd`);
 }  
}
var res = add(25,3);
checkEvenOdd(res);


console.log(`<-------------->`);

var num = 153;
var strN = num.toString();
var n = strN.length;
var sum = 0;
for(let i=0; i<n; i++){
var digit = parseInt(strN[i]);
sum = sum + Math.pow(digit,n);
}
if(sum == num){
 console.log(`${num} is an Armstrong No.`);
}
else{
 console.log(`${num} is not an Armstrong No.`);
}


console.log(`<--------------->`);

//Anonymous function 
var Demo = function(n){
var fact=1;
for(let i=2; i<=n; i++){
  fact *= i;
}
console.log(`Factorial of ${n} : ${fact} `);
}
var n = 5;
Demo(n);

console.log(`<----------------->`);

var demo1 = (n) => {
  var fact = 1;
  for(let i=1; i<=n; i++){
    fact *= i;
  }
console.log(`${fact}`)
}
demo1(5);

console.log(`<------------->`)

console.log(`Before function execution`);
function demo2(){
  console.log(`Demo function invoked`);
}
var t = setTimeout(demo2,2000);
// clearTimeout(t);
console.log(`After function execution`);



var num = 153;
