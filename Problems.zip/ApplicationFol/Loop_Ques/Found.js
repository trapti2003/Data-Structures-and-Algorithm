/*var arr = [10,20,44,11,22];
var n = 11;
function FoundEement(arr,n){
var flag = true;
for(let i in arr){
    if(n == arr[i]){
        console.log(`${n} is found at index ${i}`);
        flag = false;
    }
}
if(flag == true){
    console.log(`${n} is not found`);
}
}
FoundEement(arr,n);
*/


var arr1 = [12,34,53,45];
var n1 = 12;
function Found(arr1,n1){
    var flag = true;
    for(let i in arr1){
      if(n1 == arr1[i]){
        console.log(`${n1} is found at index ${i}`);
        flag = false;
      }
}
if(flag == true){
    console.log(`${n1} is not found`);
}
}
Found(arr1,n1);