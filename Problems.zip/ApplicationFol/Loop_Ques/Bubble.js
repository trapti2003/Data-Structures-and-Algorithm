var arr = [10,12,31,30,21];
var l = arr.length;
for(let i=0; i<l-1; i++){
    for(let j=0; j<l-1; j++){
        if(arr[j]>arr[j+1]){
            let temp = arr[j];
            arr[j] = arr[j+1];
            arr[j+1] = temp;
        }
    }
}
console.log(`After Sorting array : ${arr}`);
