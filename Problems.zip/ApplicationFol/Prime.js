var n = 2;
var flag = true;
for(let i=2; i<n/2; i++){
    if(n%2 == 0){
        flag = false;
    }
}
if(flag) console.log(`${n} is Prime`);
else console.log(`${n} is not Prime`);