/*var num = 28;
function checkPerfect(num) {
 return new Promise((res)=>{
  let flag = false;
  let sum=0;
  for(let i=1; i<num; i++) {
   if(num%i == 0)
    sum += i;
  }
  if(sum == num)
   flag = true;
  res(flag);
 });
}
(async ()=>{
 let result = await checkPerfect(num);
 if(result)
  console.log(`${num} is a perfect number`);
 else
  console.log(`${num} is not a perfect number`);
})();
*/


function checkPerfect1(num){
  let flag = false;
  let sum = 0;
  for(let i=1; i<num; i++){
    if(num%i ==0 )
      sum += i; 
  }
  if(sum == num) 
    console.log(`${num} is a Perfect no.`);
  else
  console.log(`${num} is not a Perfect number`);  
}

var num = 28;
checkPerfect1(num);







var n = 28;
function checkPerfectNo(){
  return new Promise((resolve) => {
    var flag = false;
    var sum = 0;
    for(let i=1; i<n; i++){
      if(num%i == 0)
        sum = sum + i;  
      }
      if(sum == n)
        {
          resolve(`${n} is Perfect`);
        }
        else{
          resolve(`${n} is not a Perfect no.`);
        }
      // resolve(flag);
    });
}

checkPerfectNo(n).then((result)=>{
  console.log(`${n} is Perfect`);
}).catch((error) => {
  console.log(error);
});


// if(sum == n)
//   console.log(`${n} is Perfect`);
// else
// console.log(`${n} is not perfect`);







var num1 = 28;
var sum = 0;
for(let i=1; i<num; i++){
  if(num1%i==0){
    sum = sum + i;
  }
}
if(sum==num1){
  console.log(`${num1} : Perfect No.`);
}
else{
  console.log(`${num1} : Not Perfect No.`);
}

