var n=5;
console.log("Fibonacii Series : ");
var a,b;
a=-1;b=1;
var temp;
for(let i=0; i<=n; i++){
    temp = a+b;
    a = b;
    b = temp;
    console.log(temp);
}


//Default function
/*
 function Fibo(n){
    var a,b;
    a=0;b=1;
    var temp;
    for(let i=0; i<=n; i++){
    temp = a+b;
    a = b;
    b = temp;
    console.log(temp);
  }
}

var n=4;
console.log("Fiboncii Series : " + n);
Fibo(n);
*/