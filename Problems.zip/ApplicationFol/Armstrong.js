/*let x = ["hii","hello","good"];
for(let hero of x){
    console.log(hero + " : " + hero.toUpperCase());
}
console.log("<------>")

let h = ["Good","Morning","HII"];
for(let hero of h){
    console.log(hero + " : " + hero.toLowerCase());
}


let x = ["1","2","35","54"];
for(let i in x){
    console.log(i);
}


// Task 
var arr = [85,97,44,37,76,60];
var sum=0,avg;
for(let x of arr){
    sum += x;
    avg = parseInt(sum/arr.length);
}
console.log("Average = " = avg);


var arr = [250,645,300,900,50];
for(let i=0; i<arr.length; i++){
    let offer = arr[i]/10;
    arr[i] -= offer;
}
console.log("After Discount : ")
console.log(arr);

*/

/*
var n=153;
var digit,sum=0;
var count=0,power=1;
for(let i=n; i>=1; i=i/10){
    count++;
}
// console.log(count);
while(n>0){
    digit = n%10;
        sum = sum + Math.pow(digit,n);
         n = parseInt(n/10);
}
if(sum == n){
    console.log(n + " is an Armstrong number");
}
else{
    console.log(n + " is not an Armstrong number");
}
*/

/*
var num=123;
var strN = num.toString();
var n = strN.length;
var sum=0;
for(let i=0; i<n; i++){
    var digit = parseInt(strN[i]);
    sum = sum + Math.pow(digit,n);
}
if(sum == num){
    console.log(`${num} is an Armstrong number`);
}
else{
    console.log(`${num} is not an Armstrong number`);
}
*/

console.log(`Armstrong Series from 100 to 999--> `);
for(let i=100; i<=999; i++){
    let strN = i.toString();
    let sum = 0;
    for(let i=0; i<strN.length; i++){
        var digit = parseInt(strN[i]);
        sum = sum+Math.pow(digit,strN.length);
    }
if(sum == i){
    console.log(`${i}`);
}
}






var num = 153;
var strN = num.toString();
var n = strN.length;
var sum = 0;
for(let i=0; i<n; i++){
    var digit = parseInt(strN[i]);
    sum = sum + Math.pow(digit,n);
}
if(sum == num){
    console.log(`${num} is an Armstrong`);
}
else{
    console.log(`${num} is not an Armstrong`);
}