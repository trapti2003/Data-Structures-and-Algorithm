/*//Square of a no.
var num=4;
function square(num){
   let sq = num*num;
   console.log(`Square of ${num} = ${sq}`);
}
square(num);
*/


/*//Swapping of 2 no.
var a=10, b=20;
function Swap(a,b){
console.log(`Before Swapping`);
console.log(`a = ${a} , b = ${b}`);
let temp;
temp = a;
a=b;
b=temp;
console.log(`After swapping`);
console.log(`a = ${a} , b = ${b}`);
}
Swap(a,b);
*/

/*
//Area of Triangle 
var l=10,b=30;
function AreaOFTriangle(l,b){
   let area = parseInt((1/2)*l*b);
   console.log(`Area of Triangle ${area}`); 
}
AreaOFTriangle(l,b);
*/


/*
//Area of circle
var r = 2;
function AreaOfCircle(r){
    let area  = 3.14*r*r;
console.log(`Area of Circle = ${area}`);
}
AreaOfCircle(r);
*/

/*
//Simple Intrest
var P,R,T;
P=100,R=200,T=20;
function SimpleIntrest(P,R,T){
     return new Promise((resolve) =>{
     let SI = (P*R*T)/100;
console.log(`Simple Intrest = ${SI}`);
});
}
async function Demo(){
  console.log(await SimpleIntrest(P,R,T));
}
Demo();
*/

/*
//Average of three digit number
var a=10,b=20,c=40;
function average(a,b,c){
return new Promise((resolve) => {
    var average = (a+b+c)/3;
 console.log(`Average of three no. =  ${average}`);
}); 
}
async function Demo(){
 console.log(await average(a,b,c));
}
Demo();
*/


/*
//C to F
var C = 23;
function CelciusToFarenheit(C){
   let F = (9/5)*C+32;
   console.log(`Celcius To Farenheit Conversion = ${F}`);
}
CelciusToFarenheit(C);
*/



/*
//Armstrong number
var num = 153;
var strN = num.toString();
var n = strN.length;
var sum = 0;
for(let i=0; i<n; i++){
   var digit = parseInt(strN[i]);
  sum = sum  + Math.pow(digit,n);
} 
if(sum == num){
 console.log(`${num} is an Armstrong`);
}
else{
console.log(`${num} is not an Armstrong number`);
}
*/ 


/*
var num = 153;
function Armstrong(num){
return new Promise((resolve) => {
var strN = num.toString();
var n = strN.length;
var sum = 0;
for(let i=0; i<n; i++){
  var digit = parseInt(strN[i]);
  sum = sum + Math.pow(digit,n);
}
if(sum == num)
{
  console.log(`${num} is an Armstrong`);
}
else{
  console.log(`${num} is not an Armstrong`);
}
});
}

async function Demo(){
 await Armstrong(num);
}
Demo();
*/



//var num = 23;
//var n =100 , m = 999;
for(let i=100; i<=999; i++){
    let strN = i.toString();
    let sum = 0;
for(let i=0; i<strN.length; i++){
 let digit = parseInt(strN[i]);
 sum = sum + Math.pow(digit,strN.length);
}
if(sum == i){
console.log(i);
}
}

/*
for(let i = 100; i<=999; i++)
{
  let strN = i.toString();
  let sum =0;
 for(let i=0; i<strN.length; i++){
      let digit = parseInt(strN[i]);
      sum = sum + Math.pow(digit,strN.length);
}
if(sum == i){
  console.log(i);
}
}
*/



var num = 153;
var strN = num.toString();
var n = strN.length;
let sum=0;
for(let i=0; i<n; i++){
let digit = parseInt(strN[i]);
sum += Math.pow(digit,n);
}
if(sum == n){
console.log(`${num} is an Armstrong number`);
}
else{
console.log(`${num} is not an Armstrong number`);
}

