/*
var num = 123;
var strN = num.toString();
var n = strN.length;
var sum=0;
for(let i=0; i<n; i++){
    var digit = parseInt(strN[i]);
    sum = sum + Math.pow(digit,n);
}
if(sum == num){
    console.log(`${num} is an armstrong no.`);
}
else{
    console.log(`${num} is not an armstrong no.`);
}
*/


/*
var num = 120;
var reverse = 0;
for(let i=num; i>0; i=parseInt(i/10)){
    reverse = reverse * 10 + parseInt(i%10);
}
if(reverse == num){
    console.log(`${num} is Pallindrom`);
}
else{
    console.log(`${num} is not Pallindrom`);
}
*/


/*
var n = 8;
let a=-1,b=1;
 console.log(`Fabonacci Series :`);
for(let i=0; i<=n; i++){
    var c = a+b;
    a=b;
    b=c;
    console.log(`${c}`);
}
*/



/*
var n = 123;
var reverse = 0;
for(let i=n; i>0; i=parseInt(i/10)){
    reverse = reverse * 10 + parseInt(i%10);
}
console.log(`Reverse digit : ${reverse}`);
*/


/*
var n = 5;
var Factorial = function(n){
var fact = 1;
for(let i=1; i<=n; i++){
    fact = fact*i;
}
console.log(`Factorial of ${n} : ${fact}`);
}
Factorial(n);
*/





var num = 5;
var fact = 1;
for(let i=1; i<=num; i++){
    fact = fact*i;
}
console.log(`Factorial of ${num} : ${fact}`);



var num = 153;
var strN = num.toString();
var n = strN.length;
var sum = 0;
for(let i=0; i<n; i++){
    var digit = parseInt(strN[i]);
    sum += Math.pow(digit,n);
}
if(sum==num){
    console.log(`${num} is an Armmstrong Number`);
}
else{
    console.log(`${num} is not an Armstrong Number`);
}




//Study - React project architecture
