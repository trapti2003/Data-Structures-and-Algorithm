// require("express");
var a,b,c;
a=10,b=20;
c=a+b;
console.log("Add = ",c); 