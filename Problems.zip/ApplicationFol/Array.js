/*
var arr = [[2,3,4],[3,1,2],[2,9,3]];
 for(let x of arr){
    for(let y of x){
       console.log(y);        
    //console.log(`\n`);  
}
 }
*/

/*
var arr = [[10,20,30],[2,3,1],[5,2,9]];
var sum = 0;
for(let x of arr){
  for(let y of x){
   sum+=y;
 }
}
console.log(`Sum of array elements = ${sum}`);
*/

/*
var a = [[10,20,30],[30,21,22],[23,45,78]];
var b = [[20,12,23],[21,56,65],[78,89,12]];
for(let i=0; i<3; i++){
 //var c.push([]);
 for(let j=0;  j<3;  j++){
  var c[i][j] = a[i][j] + b[i][j];
 }
}
for(let i=0; i<3; i++){
for(let i=0; i<3; i++){
  console.log("c[i][j]");
}
console.log("\n");
}



*/