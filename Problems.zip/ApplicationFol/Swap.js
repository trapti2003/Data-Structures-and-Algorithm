var a=20,b=30;
var temp;
temp = a;
a = b;
b = temp;
console.log(" a = " + a + " b = " + b);
