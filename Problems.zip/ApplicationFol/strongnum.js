var num = 145;
var ONum = num;
var sum = 0;
while(num > 0){
    var lastDigit = num%10;
    var fact = Factorial(lastDigit);
    num = parseInt(num/10);
    sum = sum + fact;
}
if(ONum == sum){
    console.log(`${ONum} is strong number`);
}
else{
    console.log(`${ONum} is not a strong number`);
}

function Factorial(num){
    var fact = 1;
    for(let i=1; i<=num; i++){
        fact *= i;
    }
    // console.log(`Factorial if ${n} : ${fact}`);
    return fact;
}

