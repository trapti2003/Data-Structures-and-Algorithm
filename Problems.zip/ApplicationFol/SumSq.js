/*
//Sync function
function sumSqr(n){
var sum = 0;
for(let i=0; i<=n; i++){
    sum = sum + i;
    var sqr = sum * sum;
}
return sqr;
}
var n = 10;
var res = sumSqr(n);
console.log(`Sum of square of ${n} natural number = ${res}`);
*/


/*
//Async function 
function sumSqr(n,cb){
    var sum = 0,sqr;
    for(let i=0; i<=n; i++){
        sum = sum + i;
        sqr = sum * sum;
    }
    setTimeout(()=>{
        cb(n);
    },2000);
}
var n = 10;
sumSqr(n,(result) => {
    console.log("Sum of square of " + n + " natural number = " + result);    
});
*/

/*
//Promise function
function sumSqr(n){
    return new Promise((resolve) => {
        var sum = 0;
        for(let i=0 ;i<=n; i++){
            sum = sum + i;
            var sqr = sum * sum;
            resolve(sum);
        }
    });
}
var n=10;
sumSqr(n).then((sqr)=>{
    console.log("Sum of square of " + n + " natural number = " + sqr); 
}).catch((error) => console.log(error));
*/



function sumSqr(n){
    return new Promise((res) => {
        var sum = 0;
        for(let i=0; i<=n; i++){
            sum =sum + i;
            var sqr = sum * sum;
        }
        res(sqr);
    });
}

var n = 10; 
async function test(){
console.log(`Sum of first ${n} natural no. = ${await sumSqr(n)}`);
}
 
test();
