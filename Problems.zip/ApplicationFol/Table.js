/*function printTable(n){
    return new Promise((resolve)=>{
        for(let i=0; i<=10; i++){
            console.log(n + " * " + i + " = " + n*i);
         }
         resolve(n);
    });

}
var n = 3;
async function test(){
   var res = await printTable(n);
}

test();
*/

function table(n){
    return new Promise((res) => {
        for(let i=0; i<=10; i++){
            var result  = n*i;
            var x = console.log(`${n} * ${i} = ${result}`);
        }
        res(x);
    });
}

var n=3;
table(n).then((x) =>{
  console.log(`${x}`);
});