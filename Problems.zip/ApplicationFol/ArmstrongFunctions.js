//Default function
/*
function Armstrong(sum,num){
    var strN = num.toString();
    var n = strN.length;
    for(let i=0; i<n; i++){
        var d`igit = parseInt(strN[i]);
        sum += Math.pow(digit,n);
    }
    if(sum == num){
        console.log(num + " is an armstrong number");
    }
    else{
        console.log(num + " is not an armstrong number");
    }
    }
    var num=154;
    var sum=0;
    Armstrong(sum,num);
    
*/

//Anonynous function
/*
var Armstrong = function(sum,num){
    var strN = num.toString();
    var n = strN.length;
    for(let i=0; i<n; i++){
        var digit = parseInt(strN[i]);
        sum += Math.pow(digit,n);
    }
    if(sum == num){
        console.log(num + " is an armstrong number");
    }
    else{
        console.log(num + " is not an armstrong number");
    }
}  
var num=153;
var sum=0;
Armstrong(sum,num);
*/


//Arrow function 
/*
var Armstrong = (sum,num) =>{
     var strN = num.toString();
     var n = strN.length;
     var sum = 0;
     for(let i=0; i<n; i++){
       var digit = parseInt(strN[i]);
       sum = sum + Math.pow(digit,n);
     }
     return (sum,num);
}
var num = 153;
var sum=0;
Armstrong(sum,num);
if(sum == num){
    console.log(num + " is an Armstrong no.");
}
else{
    console.log(num + " is not an Armstrong no.");
}
*/

/*
//promise 
function Armstrong(sum,num){
    return new Promise((resolve)=>{
        var strN = num.toString();
        var n = strN.length;
        for(let i=0; i<n; i++){
            var digit = parseInt(strN[i]);
            sum += Math.pow(digit,n);
        }
        resolve(sum);
    });
    }
    var num=153;
    var sum=0;
    Armstrong(sum,num).then((response)=>{
        if(response == num){
            console.log(num + " is an armstrong number");
        }
        else{
            console.log(num + " is not an armstrong number");
        }

    });
*/


//Async-await 
function Armstrong(sum,num){
    return new Promise((resolve) => {
    var strN = num.toString();
    var n = strN.length;
    for(let i=0; i<=n; i++){
        var digit = parseInt(strN[i]);
        sum += Math.pow(digit,n);
    }
    if(sum == num){
        console.log(num + " is an armstrong number");
    }
    else{
        console.log(num + " is not an armstrong number");
    }
    });
}
var num=154;
var sum=0;

async function test(){
    console.log(await Armstrong(sum,num));
};

test();




var num = 153;
var strN = num.toString();
var n = strN.length;
var sum = 0;
for(let i=0; i<n; i++){
    var digit = parseInt(strN[i]);
    sum = sum + Math.pow(digit,n);
}
if(sum == num){
    console.log(`${num} is an Armstrong`);
}
else{
    console.log(`${num} is not an Armstrong`);
}