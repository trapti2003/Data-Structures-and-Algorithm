var arr = ["Hello" , "Good" , "Morning"];

arr.forEach((val) =>{
    console.log("--------");
    console.log(val);
    console.log(val.toUpperCase());
});

